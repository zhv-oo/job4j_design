# job4j_design
[![Build Status](https://travis-ci.com/zhv-oo/job4j_design.svg?branch=master)](https://travis-ci.com/zhv-oo/job4j_design)
[![codecov](https://codecov.io/gh/zhv-oo/job4j_design/branch/master/graph/badge.svg?token=ZVN55CQ643)](https://codecov.io/gh/zhv-oo/job4j_design)